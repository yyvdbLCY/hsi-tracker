# HSI 牛熊街貨 + 期權 OI 封存 (2026-07-03 ~ 2026-09-10)

## 內容
- `archive/cbbc_*.json` (50 個): 每日 CBBC 牛熊街貨分布 (法興來源)
- `archive/options_oi_*.json` (13 個, 在 options_archive/): 每日 HSI 即月期權 OI 牆位
- `cbbc_distribution.json`: 最新 CBBC 主檔
- `options_oi_distribution.json`: 最新 OI 主檔

## 來源
- CBBC: 法興 (hk.warrants.com) hk-data/chart/stock_cbbc_real2.cgi
- OI: hk.warrants.com oichart.cgi (HKEX 港交所官方, T+0 21:00 HKT)

## 時間範圍
- CBBC: 2026-07-03 ~ 2026-09-10 (50 天, 平日 + 部分週末)
- OI: 2026-07-20 ~ 2026-09-10 (13 個有 OI 抓的日子)

## 數據 schema (CBBC)
- `date`: 資料日期 (YYYY-MM-DD)
- `hsi`: 恒指收市價
- `summary.bull_500` / `bear_500`: 近價 500 點內牛/熊證張數 (全市場口徑, d1 字段)
- `summary.bull_1000` / `bear_1000`: 近價 1000 點內牛/熊證張數
- `summary.bull_pct` / `bear_pct`: 牛/熊街貨比例
- `summary.total_bull` / `total_bear`: 牛/熊證總張數
- `distribution[]`: 100 點範圍聚合的 CBBC 分布
  - `type`: bull / bear
  - `strike`: range 中位
  - `low` / `high`: range 下/上界
  - `volume`: 該 range 的全市場街貨張數 (d1 字段)

## 數據 schema (Options OI)
- `date`: 資料日期
- `update_time`: 來源更新時間
- `last_close`: 上日收市
- `call_pct` / `put_pct`: 認購/認沽街貨比例
- `total_call_oi` / `total_put_oi`: 認購/認沽 OI 總和
- `strikes[]`: 92 個 strike 的 OI 詳情
  - `strike` / `type` (call/put)
  - `call_oi` / `put_oi`
  - `call_oi_change` / `put_oi_change`: 日變
  - `call_flags` / `put_flags`: 標籤 (重貨區/最多新增)

## 注意事項
- 早期 (7/3 ~ 8/12 左右) CBBC summary 只有 `bull_500` / `bear_500`, 沒 `bull_1000` (那時新指標還沒加)
- 9/10 開市期間抓的資料, HSI 仍是 9/9 收市值 (法興 API 收市後才更新)
- 期權 OI 從 7/20 才開始抓 (早於此期權 OI 沒建檔)
